import logo from './logo.svg';
import './App.css';
import Otp from './Otp';

function App() {
  return (
    <div className="App">
      <Otp />
    </div>
  );
}

export default App;
